from django.db import models


class EwayResponse(models.Model):
    pass
